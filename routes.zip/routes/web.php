<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PickupController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PacketDetailController;
use App\Http\Controllers\PaymentDetailController;

Route::get('/', function () {
    return view('main');
})->name('login')->middleware('guest');

Route::middleware('auth')->group(function () {

    Route::get('/home', function () {
        return view('home');
    });

    // GANTI: dari closure ke controller
    Route::get('/pickup', [PickupController::class, 'index'])->name('pickup.index');
    Route::post('/pickup', [PickupController::class, 'store'])->name('pickup.store');
    Route::post('/packetdetail', [PacketDetailController::class, 'store'])->name('packetdetail.store');
    Route::post('/payment', [PaymentController::class, 'store'])->name('payment.store');
    // Route::get('/paymentdetail', function () {
    //     return view('layouts.paymentdetail', [
    //         'payment' => \App\Models\Payment::with('packetDetail.pickup')->latest()->first()
    //     ]);
    // });
    Route::get('/paymentdetail', [PaymentDetailController::class, 'index'])->name('paymentdetail.index');

    Route::patch('/payment/{id}/confirm', [PaymentController::class, 'confirm'])->name('payment.confirm');




    // Tetap static view
    Route::get('/order-detail', function () {
        return view('layouts.orderdetail');
    });

    Route::get('/account', function () {
        return view('layouts.account');
    });

    Route::get('/dashboard', function () {
        return view('dashboard');
    })->middleware(['auth', 'verified'])->name('dashboard');

    // Berikutnya akan kita ganti ke controller juga (setelah pickup)
    Route::get('/packetdetail', function () {
        return view('layouts.packetdetail');
    });
    Route::get('/payment', [PaymentController::class, 'index'])->name('payment.index');
    Route::post('/packetdetail', [PacketDetailController::class, 'store'])->name('packetdetail.store');

    // Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__ . '/auth.php';

